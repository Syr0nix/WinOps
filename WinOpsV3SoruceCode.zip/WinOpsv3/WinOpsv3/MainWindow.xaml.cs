﻿using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WinOpsV3
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CheckToggleStates();
        }

        private void ShowProgress(string message = "")
        {
            ProgressBarMain.Visibility = Visibility.Visible;
            StatusText.Text = message;
            StatusText.Visibility = string.IsNullOrWhiteSpace(message) ? Visibility.Collapsed : Visibility.Visible;
        }

        private void HideProgress()
        {
            ProgressBarMain.Visibility = Visibility.Collapsed;
            StatusText.Visibility = Visibility.Collapsed;
        }

        private void RunCmd(string cmd, string title = "Executing...")
        {
            var psi = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/k title {title} & {cmd}",
                UseShellExecute = true,     // Needed for visible + runas
                Verb = "runas",             // Run as admin
                WindowStyle = ProcessWindowStyle.Normal
            };

            try
            {
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to launch command:\n" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void RunApp(string path)
        {
            Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }

        private void OnPowerPlanClicked(object sender, RoutedEventArgs e) =>
            RunCmd("powercfg -setactive SCHEME_MIN", "Applying High Performance Power Plan...");

        private void OnAdjustPerformanceClicked(object sender, RoutedEventArgs e) =>
            RunApp("systempropertiesperformance");

        private void OnStartupClicked(object sender, RoutedEventArgs e) =>
            RunApp("ms-settings:startupapps");

        private void OnVisualToggled(object sender, RoutedEventArgs e)
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"))
                key.SetValue("VisualFXSetting", VisualToggle.IsChecked == true ? 2 : 0, RegistryValueKind.DWord);
        }

        private void OnXboxToggled(object sender, RoutedEventArgs e)
        {
            using (RegistryKey gb = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\GameBar"))
                gb.SetValue("AllowAutoGameMode", XboxToggle.IsChecked == true ? 0 : 1, RegistryValueKind.DWord);
        }

        private void OnTcpAutoToggled(object sender, RoutedEventArgs e)
        {
            string mode = TcpAutoToggle.IsChecked == true ? "disabled" : "normal";
            RunCmd($"netsh interface tcp set global autotuning={mode}", "Toggling TCP Autotuning...");
        }

        private void OnRestartToBiosClicked(object sender, RoutedEventArgs e) =>
            RunCmd("shutdown /r /fw /f /t 0", "Restarting to BIOS...");

        private void OnInstall7zipClicked(object sender, RoutedEventArgs e) =>
            RunCmd("winget install 7zip.7zip", "Installing 7-Zip...");

        private void OnInstallWinRARClicked(object sender, RoutedEventArgs e) =>
            RunCmd("winget install winrar", "Installing WinRAR...");

        private void OnComponentCleanupClicked(object sender, RoutedEventArgs e) =>
            RunCmd("dism /online /cleanup-image /startcomponentcleanup", "Running Windows Component Cleanup...");

        private void OnImageCheckClicked(object sender, RoutedEventArgs e)
        {
            string script = @"
                 dism /online /cleanup-image /restorehealth
                 sfc /scannow
                 cls
                 exit";

            string tempBat = System.IO.Path.GetTempFileName().Replace(".tmp", ".bat");
            System.IO.File.WriteAllText(tempBat, script);

            RunCmd($"call \"{tempBat}\"", "Running System Image Check...");
        }


        private void OnNetworkRefreshClicked(object sender, RoutedEventArgs e) =>
            RunCmd("ipconfig /release && ipconfig /renew && ipconfig /flushdns", "Refreshing IP and Flushing DNS...");

        private void OnNetworkOptimizeClicked(object sender, RoutedEventArgs e)
        {
            string script = @"
                    netsh interface tcp set global autotuning=high
                    netsh int ipv4 set subinterface ""Ethernet"" mtu=1500 store=persistent
                    netsh int ipv6 set subinterface ""Ethernet"" mtu=1500 store=persistent
                    netsh int ipv4 set subinterface ""Wi-Fi"" mtu=1500 store=persistent
                    netsh int ipv6 set subinterface ""Wi-Fi"" mtu=1500 store=persistent
                    netsh int ipv4 set subinterface ""Bluetooth"" mtu=1500 store=persistent
                    netsh int ipv6 set subinterface ""Bluetooth"" mtu=1500 store=persistent
                    netsh interface ip set dns ""Ethernet"" static 1.1.1.1
                    netsh interface ip add dns ""Ethernet"" 8.8.8.8 index=2
                    netsh interface ip set dns ""Wi-Fi"" static 1.1.1.1
                    netsh interface ip add dns ""Wi-Fi"" 8.8.8.8 index=2
                    netsh interface ip set dns ""Bluetooth Network Connection"" static 1.1.1.1
                    netsh interface ip add dns ""Bluetooth Network Connection"" 8.8.8.8 index=2
                    netsh interface ipv6 set dnsservers ""Ethernet"" static 2606:4700:4700::1111
                    netsh interface ipv6 add dnsservers ""Ethernet"" 2001:4860:4860::8888 index=2
                    netsh interface ipv6 set dnsservers ""Wi-Fi"" static 2606:4700:4700::1111
                    netsh interface ipv6 add dnsservers ""Wi-Fi"" 2001:4860:4860::8888 index=2
                    netsh interface ipv6 set dnsservers ""Bluetooth Network Connection"" static 2606:4700:4700::1111
                    netsh interface ipv6 add dnsservers ""Bluetooth Network Connection"" 2001:4860:4860::8888 index=2
                    netsh interface 6to4 set state disabled
                    netsh int isatap set state disable
                    netsh int tcp set global timestamps=disabled
                    netsh int tcp set heuristics disabled
                    netsh int tcp set global ecncapability=disabled
                    netsh int tcp set global rsc=disabled
                    netsh int tcp set global nonsackrttresiliency=disabled
                    netsh int tcp set security mpp=disabled
                    netsh int tcp set security profiles=disabled
                    netsh int ip set global icmpredirects=disabled
                    netsh int ip set global multicastforwarding=disabled
                    netsh int tcp set supplemental internet congestionprovider=ctcp
                    netsh interface teredo set state disabled
                    netsh winsock reset
                    netsh int ip set global taskoffload=disabled
                    netsh int ip set global neighborcachelimit=4096
                    netsh int tcp set global dca=enabled
                    netsh int tcp set global netdma=enabled
                    powershell -Command ""Get-NetAdapter | ForEach-Object { Disable-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue }""
                    powershell -Command ""Get-NetAdapter | ForEach-Object { Disable-NetAdapterLso -Name $_.Name -ErrorAction SilentlyContinue }""
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v EnableICMPRedirect /t REG_DWORD /d 1 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v EnablePMTUDiscovery /t REG_DWORD /d 1 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v Tcp1323Opts /t REG_DWORD /d 0 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v TcpMaxDupAcks /t REG_DWORD /d 2 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v TcpTimedWaitDelay /t REG_DWORD /d 32 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v GlobalMaxTcpWindowSize /t REG_DWORD /d 8760 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v TcpWindowSize /t REG_DWORD /d 8760 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v MaxConnectionsPerServer /t REG_DWORD /d 0 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v MaxUserPort /t REG_DWORD /d 65534 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v SackOpts /t REG_DWORD /d 0 /f
                    reg add ""HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"" /v DefaultTTL /t REG_DWORD /d 64 /f
                    reg add ""HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"" /v NetworkThrottlingIndex /t REG_SZ /d ffffffff /f
                cls
            exit";

            string tempBat = System.IO.Path.GetTempFileName().Replace(".tmp", ".bat");
            System.IO.File.WriteAllText(tempBat, script);

            RunCmd($"\"{tempBat}\"", "Running Full Network Optimization...");
        }
        private void OnRemoveSpywareClicked(object sender, RoutedEventArgs e)
        {
            string script = @"
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy"" /v ""TailoredExperiencesWithDiagnosticDataEnabled"" /t REG_DWORD /d 0 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy"" /v ""LetAppsAccessActivity"" /t REG_DWORD /d 0 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy"" /v ""PublishUserActivities"" /t REG_DWORD /d 0 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo"" /v ""Enabled"" /t REG_DWORD /d 0 /f
reg add ""HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection"" /v ""AllowTelemetry"" /t REG_DWORD /d 0 /f
sc stop DiagTrack
sc config DiagTrack start= disabled
sc stop dmwappushsvc
sc config dmwappushsvc start= disabled
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"" /v ""SubscribedContent-338393Enabled"" /t REG_DWORD /d 0 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"" /v ""SubscribedContent-353694Enabled"" /t REG_DWORD /d 0 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\Search"" /v ""CortanaConsent"" /t REG_DWORD /d 0 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager"" /v ""SubscribedContent-310093Enabled"" /t REG_DWORD /d 0 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications"" /v ""GlobalUserDisabled"" /t REG_DWORD /d 1 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\Privacy"" /v ""TailoredExperiencesWithDiagnosticDataEnabled"" /t REG_DWORD /d 0 /f
reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location"" /v ""Value"" /t REG_SZ /d ""Deny"" /f
sc stop WSearch
sc config WSearch start= disabled
echo 0.0.0.0 vortex.data.microsoft.com >> %windir%\System32\drivers\etc\hosts
echo 0.0.0.0 settings-win.data.microsoft.com >> %windir%\System32\drivers\etc\hosts
echo 0.0.0.0 watson.telemetry.microsoft.com >> %windir%\System32\drivers\etc\hosts
reg add ""HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors"" /v ""DisableLocation"" /t REG_DWORD /d 1 /f
gpupdate /force
cls
exit
";

            string tempBat = System.IO.Path.GetTempFileName().Replace(".tmp", ".bat");
            System.IO.File.WriteAllText(tempBat, script);
            RunCmd($"call \"{tempBat}\"", "Removing Windows Spyware...");
        }

        private void OnCheckdiskClicked(object sender, RoutedEventArgs e)
        {
            string script = @"
                @echo off
                setlocal enabledelayedexpansion

                for %%i in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
                    echo Checking drive %%i:
                    if exist %%i:\ (
                        echo Drive %%i: is available, running CHKDSK...
                        chkdsk %%i: /scan

                        echo If it finds any problems, you may need to run: chkdsk %%i: /f after this.

                        echo Cleaning Temp files on drive %%i:...
                        del /F /S /Q %%i:\*Temp\* >nul 2>&1
                        echo Temp files cleaned on drive %%i:.

                        echo Optimizing drive %%i:...
                        defrag %%i: /U /V
                        echo Drive %%i: optimization complete.
                    ) else (
                        echo Drive %%i: is not available or offline, skipping to the next drive.
                    )
                )

                endlocal
                exit
                ";

            string tempBat = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DriveMaintenance.bat");
            System.IO.File.WriteAllText(tempBat, script);

            RunCmd($"call \"{tempBat}\"", "Running Drive Maintenance...");
        }

        private void OnCELClicked(object sender, RoutedEventArgs e) =>
            RunCmd("for /F \"tokens=*\" %%G in ('wevtutil.exe el') DO wevtutil.exe cl \"%%G\" 2>nul");

        private void OnClearARPCacheClicked(object sender, RoutedEventArgs e) =>
            RunCmd("arp -d\r\n");


        private void OnUpgradePackagesClicked(object sender, RoutedEventArgs e) =>
            RunCmd("winget upgrade --all", "Upgrading All Packages...");

        private void OnCleanTempClicked(object sender, RoutedEventArgs e) =>
            RunCmd("del /q /f /s %TEMP%\\* && del /q /f /s C:\\Windows\\Prefetch\\*", "Cleaning Temp + Prefetch Files...");

        private void OnClearRAMClicked(object sender, RoutedEventArgs e) =>
            RunCmd("rundll32.exe advapi32.dll,ProcessIdleTasks", "Clearing RAM Cache...");

        private void OnResetNetClicked(object sender, RoutedEventArgs e) =>
            RunCmd("netsh winsock reset && ipconfig /flushdns", "Resetting Network Stack...");

        private void OnActivateClicked(object sender, RoutedEventArgs e)
        {
            string selected = (KeyList.SelectedItem as ComboBoxItem)?.Content?.ToString();
            if (string.IsNullOrEmpty(selected))
            {
                MessageBox.Show("Please select a Windows version.");
                return;
            }

            string key = null;

            if (selected == "Windows 10 Home") key = "TX9XD-98N7V-6WMQ6-BX7FG-H8Q99";
            else if (selected == "Windows 10 Home N") key = "3KHY7-WNT83-DGQKR-F7HPR-844BM";
            else if (selected == "Windows 10 Home Single Language") key = "7HNRX-D7KGG-3K4RQ-4WPJ4-YTDFH";
            else if (selected == "Windows 10 Home Country Specific") key = "PVMJN-6DFY6-9CCP6-7BKTT-D3WVR";
            else if (selected == "Windows 10 Pro") key = "W269N-WFGWX-YVC9B-4J6C9-T83GX";
            else if (selected == "Windows 10 Pro N") key = "MH37W-N47XK-V7XM9-C7227-GCQG9";
            else if (selected == "Windows 10 Education") key = "NW6C2-QMPVW-D7KKK-3GKT6-VCFB2";
            else if (selected == "Windows 10 Education N") key = "2WH4N-8QGBV-H22JP-CT43Q-MDWWJ";
            else if (selected == "Windows 10 Enterprise") key = "NPPR9-FWDCX-D2C8J-H872K-2YT43";
            else if (selected == "Windows 10 Enterprise N") key = "DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4";
            else if (selected == "Windows Server 2025 Standard") key = "TVRH6-WHNXV-R9WG3-9XRFY-MY832";
            else if (selected == "Windows Server 2025 Datacenter") key = "D764K-2NDRG-47T6Q-P8T8W-YP6DF";
            else if (selected == "Windows Server 2025 Datacenter: Azure Edition") key = "XGN3F-F394H-FD2MY-PP6FD-8MCRC";
            else if (selected == "Windows Server 2022 Standard") key = "VDYBN-27WPP-V4HQT-9VMD4-VMK7H";
            else if (selected == "Windows Server 2022 Datacenter") key = "WX4NM-KYWYW-QJJR4-XV3QB-6VM33";
            else if (selected == "Windows Server 2022 Datacenter: Azure Edition") key = "NTBV8-9K7Q8-V27C6-M2BTV-KHMXV";
            else if (selected == "Windows Server 2019 Standard") key = "N69G4-B89J2-4G8F4-WWYCC-J464C";
            else if (selected == "Windows Server 2019 Datacenter") key = "WMDGN-G9PQG-XVVXX-R3X43-63DFG";
            else if (selected == "Windows Server 2019 Essentials") key = "WVDHN-86M7X-466P6-VHXV7-YY726";
            else if (selected == "Windows Server 2016 Standard") key = "WC2BQ-8NRM3-FDDYY-2BFGV-KHKQY";
            else if (selected == "Windows Server 2016 Datacenter") key = "CB7KF-BWN84-R7R2Y-793K2-8XDDG";
            else if (selected == "Windows Server 2016 Essentials") key = "JCKRF-N37P4-C2D82-9YXRT-4M63B";


            if (string.IsNullOrEmpty(key))
            {
                MessageBox.Show("Invalid product key selected.");
                return;
            }

            // KMS fallback server list
            string[] kmsServers = { "kms9.msguides.com", "kms8.msguides.com", "kms7.msguides.com" };
            string activationScript = $"slmgr /ipk {key} & ";

            foreach (var kms in kmsServers)
            {
                activationScript += $"slmgr /skms {kms} & slmgr /ato & ";
            }

            activationScript += "echo Activation complete. && pause";

            string tempBat = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "ActivateWindowsKey.bat");
            System.IO.File.WriteAllText(tempBat, activationScript);

            RunCmd($"call \"{tempBat}\"", $"Activating {selected} with fallback...");
        }


        private void OnCloseClicked(object sender, RoutedEventArgs e) => this.Close();

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
                this.DragMove();
        }

        private void CheckToggleStates()
        {
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"))
                    VisualToggle.IsChecked = ((int?)key?.GetValue("VisualFXSetting")) == 2;
            }
            catch { VisualToggle.IsChecked = false; }

            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\GameDVR"))
                    XboxToggle.IsChecked = ((int?)key?.GetValue("AppCaptureEnabled")) == 0;
            }
            catch { XboxToggle.IsChecked = false; }

            try
            {
                var process = new Process
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = "netsh",
                        Arguments = "interface tcp show global",
                        RedirectStandardOutput = true,
                        UseShellExecute = false,
                        CreateNoWindow = true
                    }
                };

                process.Start();
                string output = process.StandardOutput.ReadToEnd();
                process.WaitForExit();

                TcpAutoToggle.IsChecked = output.Contains("Receive Window Auto-Tuning level") && output.Contains("disabled");
            }
            catch { TcpAutoToggle.IsChecked = false; }
        }
    }
}
