﻿using System.Windows;

namespace WinOpsV3
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            ElevationHelper.EnsureElevatedOrExit(); // will relaunch with UAC if needed
        }
    }
}
