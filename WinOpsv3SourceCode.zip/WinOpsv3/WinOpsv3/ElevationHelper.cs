﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Security.Principal;
using System.Windows;

namespace WinOpsV3   // <-- replace with the namespace your other files use
{
    public static class ElevationHelper
    {
        public static bool IsAdministrator()
        {
            using (var identity = WindowsIdentity.GetCurrent())
            {
                var principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        public static void EnsureElevatedOrExit()
        {
            if (IsAdministrator()) return;

            try
            {
                var exePath = Process.GetCurrentProcess().MainModule.FileName;

                var args = Environment.GetCommandLineArgs();
                var alreadyElevated = args.Any(a => string.Equals(a, "/elevated", StringComparison.OrdinalIgnoreCase));

                if (!alreadyElevated)
                {
                    var extra = args.Length > 1
                        ? " " + string.Join(" ", args.Skip(1).ToArray())
                        : string.Empty;

                    var psi = new ProcessStartInfo
                    {
                        FileName = exePath,
                        Arguments = "/elevated" + extra,
                        UseShellExecute = true,
                        Verb = "runas"
                    };

                    Process.Start(psi);
                }

                Application.Current.Shutdown();
            }
            catch (Win32Exception)
            {
                MessageBox.Show(
                    "Administrator permission is required to continue.",
                    "Elevation cancelled",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }
    }
}
